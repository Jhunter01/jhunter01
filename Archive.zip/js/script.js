$(window).load(function(){
		$('input:checkbox').change(function () {
        var name = $(this).val();
        var check = $(this).attr('checked');
        console.log("Change: " + name + " to " + check);
        });
		});